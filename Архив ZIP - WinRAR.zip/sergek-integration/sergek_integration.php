<?php
/*
Plugin Name: Sergek API Integration
Description: Интеграция форм с внешним Python API (SPA подход, без wp_users)
Version: 1.0
*/

// Подключение JavaScript и CSS к страницам
add_action('wp_enqueue_scripts', function() {
    wp_enqueue_script('sergek-app-js', plugin_dir_url(__FILE__) . 'app.js', array(), time(), true);
    
    // Передаем адрес API в JavaScript
    wp_localize_script('sergek-app-js', 'SergekConfig', array(
        'apiUrl' => 'http://127.0.0.1:8000/api'
    ));

    wp_add_inline_style('wp-block-library', '
        .api-error { color: red; font-size: 13px; margin-top: 2px; display: block; }
        .api-success { color: green; font-weight: bold; margin-bottom: 15px; }
        .sergek-form { max-width: 450px; margin: 0 auto; background: #f9f9f9; padding: 20px; border-radius: 8px;}
        .sergek-form input, .sergek-form textarea, .sergek-form select { width: 100%; margin-bottom: 10px; padding: 10px; border: 1px solid #ccc; border-radius: 4px; }
        .sergek-form button { background: #007bff; color: white; padding: 10px 15px; border: none; cursor: pointer; border-radius: 4px; width: 100%;}
        .sergek-form button:hover { background: #0056b3; }
    ');
});
// Шорткод 1: Кнопка переключения языка
add_shortcode('sergek_lang_btn', function() {
    return '
    <div style="text-align: right; margin-bottom: 15px; max-width: 400px; margin-left: auto; margin-right: auto;">
        <button id="lang-toggle" style="background: #e0e0e0; color: #333; border: none; padding: 5px 15px; border-radius: 4px; cursor: pointer; font-weight: bold;">
            Русский
        </button>
    </div>';
});

// Шорткод 2: Регистрация
add_shortcode('sergek_register', function() {
    return '
    <div class="sergek-form">
        <div id="register-msg"></div>
        <form id="form-register">
            <input type="text" id="reg-iin" placeholder="ЖСН (12 cан)" required>
            <span class="api-error" id="error-iin"></span><br>

            <input type="text" id="reg-fio" placeholder="Т.А.Ә " required>
            <span class="api-error" id="error-fio"></span><br>

            <input type="text" id="reg-phone" placeholder="Телефон +7XXX-XXX-XX-XX" required>
            <span class="api-error" id="error-phone"></span><br>

            <input type="email" id="reg-email" placeholder="Email" required>
            <span class="api-error" id="error-email"></span><br>

            <input type="password" id="reg-password" placeholder="Құпия сөз" required>
            <span class="api-error" id="error-password"></span><br>

            <button type="submit">Тіркелу</button>
        </form>
    </div>';
});

// Шорткод 3: Логин
add_shortcode('sergek_login', function() {
    return '
    <div class="sergek-form">
        <div id="login-msg"></div>
        <form id="form-login">
            <input type="text" id="log-iin" placeholder="ЖСН" required>
            <span class="api-error" id="error-login"></span><br>

            <input type="password" id="log-password" placeholder="Құпия сөз" required>
            <br>
            <button type="submit">Кіру</button>
        </form>
    </div>';
});

// Шорткод 4: Подача заявления
add_shortcode('sergek_claim', function() {
    // 1. Подключаемся к базе Сергек, а не WordPress
    $mydb = new wpdb(DB_USER, DB_PASSWORD, 'sergek_azamat_db', DB_HOST);
    
    // Получаем типы нарушений из правильной базы
    $types = @$mydb->get_results("SELECT * FROM violation_types");
    
    $options = '<option value="">Тип нарушения / Бұзушылық түрі</option>';
    if ($types) {
        foreach ($types as $type) {
            $options .= '<option value="' . esc_attr($type->id) . '">' . esc_html($type->name) . '</option>';
        }
    }   

    return '
    <div class="sergek-form" id="claim-container" style="display:none;">
        <div id="claim-msg"></div>
        <form id="form-claim" enctype="multipart/form-data">
            
            <select id="claim-type" name="violation_type_id" required>
                ' . $options . '
            </select>
            
            <input type="text" id="claim-grnz" name="grnz" placeholder="ГРНЗ (123ABC10)" required>
            <span class="api-error" id="error-grnz"></span>

            <input type="number" id="claim-region" name="region_code" placeholder="Аймақ коды (1-20)" min="1" max="20" required>
            <span class="api-error" id="error-region_code"></span>

            <input type="text" id="claim-address" name="address" placeholder="Мекен Жай" required>
            <span class="api-error" id="error-address"></span>

            <select id="claim-priority" name="priority">
                <option value="Низкий">Төмен/Низкий</option>
                <option value="Средний" selected>Орташа/Средний</option> 
                <option value="Высокий">Жоғары/Высокий</option>
            </select>

            <textarea id="claim-desc" name="description" placeholder="Сипаттама" required></textarea>
            <span class="api-error" id="error-description"></span>

            <label style="font-weight:bold; display:block; margin-top:10px;">Дәлел/Фото (3-ке дейін/до 3-х):</label>
            <input type="file" name="photo1" accept="image/png, image/jpeg" style="margin-bottom:5px;">
            <input type="file" name="photo2" accept="image/png, image/jpeg" style="margin-bottom:5px;">
            <input type="file" name="photo3" accept="image/png, image/jpeg" style="margin-bottom:15px;">
            <span class="api-error" id="error-image"></span>

            <button type="submit">Өтініш беру</button>
        </form>
    </div>
    <div id="auth-warning" style="text-align:center; color: red;">Өтініш беру үшін жүйеге кіріңіз.</div>';
});

// Шорткод 5:  Мои заявления (Вывод таблицы)
add_shortcode('sergek_my_claims', function() {
    return '
    <div style="text-align: right; max-width: 800px; margin: 0 auto 10px auto;">
        <button id="lang-toggle" type="button" style="background: #e0e0e0; color: #333; border: none; padding: 5px 15px; border-radius: 4px; cursor: pointer; font-weight: bold;">
            Русский
        </button>
    </div>

    <div id="form-my-claims" style="max-width: 800px; margin: 0 auto; background: #f9f9f9; padding: 20px; border-radius: 8px; overflow-x: auto;">
        <div id="claims-auth-warning" style="text-align:center; color: red; display: none;">
            Өтініштерді көру үшін жүйеге кіріңіз (Сначала выполните вход).
        </div>
        
        <div id="claims-table-container">
            </div>
    </div>';
});
