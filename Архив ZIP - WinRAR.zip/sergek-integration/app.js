document.addEventListener('DOMContentLoaded', function() {
    // Автоматически берем адрес из WordPress (если есть), иначе ставим дефолтный 
    const API_URL = typeof SergekConfig !== 'undefined' ? SergekConfig.apiUrl : 'http://127.0.0.1:8000/api';
    const token = localStorage.getItem('sergek_token');

    // ==========================================
    // 1. СИСТЕМА МУЛЬТИЯЗЫЧНОСТИ
    // ==========================================
    const i18n = {
        'kk': {
            nav: {
                'site-title':'Sergek Azamat Порталы',
                'menu-login':'Кіру',
                'menu-claims':'Менің өтініштерім',
                'menu-submit':'Өтініш беру',
                'menu-register':'Тіркелу'
            },
            titles: {
                'form-register':'Тіркелу',
                'form-login':'Кіру',
                'form-claim':'Өтініш беру',
                'form-my-claims':'Менің өтініштерім'
            },
            placeholders: {
                'claim-grnz':'Мем. нөмір (мысалы, 777AAA10)',
                'claim-region':'Аймақ коды (1-20)',
                'claim-address':'Мекен Жай',
                'claim-desc':'Сипаттама',
                'log-iin':'ЖСН (12 сан)',
                'log-password':'Құпия сөз',
                'reg-iin':'ЖСН (12 сан)',
                'reg-fio':'Т.А.Ә',
                'reg-phone':'Телефон +7XXX-XXX-XX-XX',
                'reg-email':'Email',
                'reg-password':'Құпия сөз (кемінде 8 таңба)'
            },
            texts: {
                'btn-submit-claim':'Өтініш беру',
                'label-image':'Дәлел (Фото):',
                'btn-submit-login':'Кіру',
                'btn-submit-reg':'Тіркелу',
                'lang-toggle':'Русский',
                'th-id':'№',
                'th-grnz':'Мем. нөмір',
                'th-region':'Аймақ',
                'th-desc':'Сипаттама',
                'th-photo':'Фото',
                'empty-claims':'Сізде әлі өтініштер жоқ.',
                'loading':'Жүктелуде...'
            }
        },
        'ru': {
            nav: {
                'site-title':'Портал Sergek Azamat',
                'menu-login':'Войти',
                'menu-claims':'Мои заявления',
                'menu-submit':'Подать заявление',
                'menu-register':'Регистрация'
            },
            titles: {
                'form-register':'Регистрация',
                'form-login':'Авторизация',
                'form-claim':'Подача заявления',
                'form-my-claims':'Мои заявления'
            },
            placeholders: {
                'claim-grnz':'Гос. номер (например, 777AAA10)',
                'claim-region':'Код региона (1-20)',
                'claim-address':'Адрес',
                'claim-desc':'Подробное описание нарушения',
                'log-iin':'ИИН (12 цифр)',
                'log-password':'Пароль',
                'reg-iin':'ИИН (12 цифр)',
                'reg-fio':'ФИО полностью',
                'reg-phone':'Телефон +7XXX-XXX-XX-XX',
                'reg-email':'Электронная почта',
                'reg-password':'Пароль (минимум 8 символов)'
            },
            texts: {
                'btn-submit-claim':'Подать заявление',
                'label-image':'Доказательство (Фото):',
                'btn-submit-login':'Войти',
                'btn-submit-reg':'Зарегистрироваться',
                'lang-toggle':'Қазақша',
                'th-id':'№',
                'th-grnz':'Гос. номер',
                'th-region':'Регион',
                'th-desc':'Описание',
                'th-photo':'Фото',
                'empty-claims':'У вас пока нет заявлений.',
                'loading':'Загрузка...'
            }
        }
    };

    let currentLang = localStorage.getItem('sergek_lang') || 'kk';

    function applyLanguage(lang) {
        const dict = i18n[lang];
        
        for (const [id, text] of Object.entries(dict.placeholders)) {
            const el = document.getElementById(id);
            if (el) el.placeholder = text;
        }

        const pageTitle = document.querySelector('h1');
        if (pageTitle) {
            for (const [formId, titleText] of Object.entries(dict.titles)) {
                if (document.getElementById(formId)) {
                    pageTitle.innerText = titleText;
                    break;
                }
            }
        }

        const formButtons = { 'form-claim':'btn-submit-claim','form-login':'btn-submit-login','form-register':'btn-submit-reg' };
        for (const [formId, textKey] of Object.entries(formButtons)) {
            const form = document.getElementById(formId);
            if (form) {
                const btn = form.querySelector('button[type="submit"]');
                if (btn) btn.innerText = dict.texts[textKey];
            }
        }

        ['label-image','lang-toggle', 'th-id','th-grnz', 'th-region','th-desc', 'th-photo','empty-claims', 'loading'].forEach(id => {
            const el = document.getElementById(id);
            if (id === 'label-image') {
                const imgLabel = document.querySelector('label[for="claim-image"]');
                if (imgLabel) imgLabel.innerText = dict.texts[id];
            } else if (el) {
                el.innerText = dict.texts[id];
            }
        });

        const navLinks = document.querySelectorAll('header a, nav a, .wp-block-navigation a'); 
        navLinks.forEach(link => {
            const text = link.innerText.trim();
            if (text === 'Sergek Azamat Порталы' || text === 'Портал Sergek Azamat') link.innerText = dict.nav['site-title'];
            if (text === 'Кіру' || text === 'Войти') link.innerText = dict.nav['menu-login'];
            if (text === 'Mental өтініштер' || text === 'Менің өтініштерім' || text === 'Мои заявления') link.innerText = dict.nav['menu-claims'];
            if (text === 'Өтініш беру' || text === 'Подать заявление') link.innerText = dict.nav['menu-submit'];
            if (text === 'Тіркелу' || text === 'Регистрация') link.innerText = dict.nav['menu-register'];
        });
    }

    applyLanguage(currentLang);

    document.addEventListener('click', (e) => {
        if (e.target && e.target.id === 'lang-toggle') {
            currentLang = currentLang === 'kk' ? 'ru' : 'kk';
            localStorage.setItem('sergek_lang', currentLang);
            applyLanguage(currentLang);
        }
    });

    // ==========================================
    // 2. ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ API
    // ==========================================
    function clearErrors(formId) { 
        document.querySelectorAll(`#${formId} .api-error`).forEach(el => el.innerText = '');
    }
    
    function displayErrors(errors) {
        for (const [field, message] of Object.entries(errors)) {
            const errorElement = document.getElementById(`error-${field}`);
            if (errorElement) errorElement.innerText = message;
        }
    }

    // ==========================================
    // 3. ЛОГИКА ФОРМ (SPA)
    // ==========================================

    // --- 3.1. РЕГИСТРАЦИЯ ---
    const formRegister = document.getElementById('form-register');
    if (formRegister) {
        formRegister.addEventListener('submit', async (e) => {
            e.preventDefault();
            clearErrors('form-register');
            const msgBox = document.getElementById('register-msg');
            msgBox.innerHTML = '<p style="color:blue;">Регистрация...</p>';

            const data = {
                iin: document.getElementById('reg-iin').value,
                fio: document.getElementById('reg-fio').value,
                phone: document.getElementById('reg-phone').value,
                email: document.getElementById('reg-email').value,
                password: document.getElementById('reg-password').value
            };

            try {
                const response = await fetch(`${API_URL}/register`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();

                if (response.ok) {
                    msgBox.innerHTML = `<p class="api-success">${result.message || 'Вы успешно зарегистрировались!'}</p>`;
                    formRegister.reset();
                } else {
                    msgBox.innerHTML = '';
                    if (result.errors) {
                        displayErrors(result.errors);
                    } else if (typeof result.detail === 'string') {
                        msgBox.innerHTML = `<p class="api-error">${result.detail}</p>`;
                    } else if (Array.isArray(result.detail)) {
                        // Обработка стандартных ошибок валидации FastAPI (Pydantic)
                        const pydanticErrors = {};
                        result.detail.forEach(err => {
                            const field = err.loc[err.loc.length - 1];
                            pydanticErrors[field] = err.msg;
                        });
                        displayErrors(pydanticErrors);
                    } else {
                        msgBox.innerHTML = `<p class="api-error">Ошибка сервера: ${response.status}</p>`;
                    }
                }
            } catch (err) {
                console.error(err);
                msgBox.innerHTML = '<p class="api-error">Ошибка соединения с сервером API. Проверьте, запущен ли бэкэнд.</p>';
            }
        });
    }

    // --- 3.2. АВТОРИЗАЦИЯ ---
    const formLogin = document.getElementById('form-login');
    if (formLogin) {
        formLogin.addEventListener('submit', async (e) => {
            e.preventDefault();
            clearErrors('form-login');
            const msgBox = document.getElementById('login-msg');
            const errorLoginSpan = document.getElementById('error-login');

            const data = { 
                iin: document.getElementById('log-iin').value, 
                password: document.getElementById('log-password').value 
            };

            try {
                const response = await fetch(`${API_URL}/login`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();

                if (response.ok) {
                    localStorage.setItem('sergek_token', result.access_token);
                    window.location.href = '/өтініш-беру/'; 
                } else {
                    const errorText = typeof result.detail === 'string' ? result.detail : (result.message || 'Неверный ИИН или пароль');
                    if (errorLoginSpan) {
                        errorLoginSpan.innerText = errorText;
                    } else if (msgBox) {
                        msgBox.innerHTML = `<p class="api-error">${errorText}</p>`;
                    }
                }
            } catch (err) {
                console.error(err);
                if (msgBox) {
                    msgBox.innerHTML = '<p class="api-error">Ошибка соединения с сервером.</p>';
                } else if (errorLoginSpan) {
                    errorLoginSpan.innerText = 'Ошибка соединения с сервером.';
                }
            }
        });
    }

    // --- 3.3. ПОДАЧА ЗАЯВЛЕНИЯ ---
    const formClaim = document.getElementById('form-claim');
    if (formClaim) {
        if (token) {
            const claimContainer = document.getElementById('claim-container');
            const authWarning = document.getElementById('auth-warning');
            if (claimContainer) claimContainer.style.display = 'block';
            if (authWarning) authWarning.style.display = 'none';
        }
        formClaim.addEventListener('submit', async (e) => {
            e.preventDefault();
            clearErrors('form-claim');
            const msgBox = document.getElementById('claim-msg');
            if (msgBox) msgBox.innerHTML = '<p style="color:blue;">Отправка... / Жіберілуде...</p>';

            const formData = new FormData(formClaim);
            try {
                const response = await fetch(`${API_URL}/claims`, {
                    method: 'POST',
                    headers: { 'Authorization': `Bearer ${token}` },
                    body: formData
                });
                
                const result = await response.json();
                if (msgBox) msgBox.innerHTML = '';
                
                if (response.status === 422) {
                    if (result.errors) displayErrors(result.errors);
                    else if (Array.isArray(result.detail)) {
                        const pydanticErrors = {};
                        result.detail.forEach(err => {
                            const field = err.loc[err.loc.length - 1];
                            pydanticErrors[field] = err.msg;
                        });
                        displayErrors(pydanticErrors);
                    }
                } else if (!response.ok) {
                    if (msgBox) msgBox.innerHTML = `<p class="api-error">${result.detail || 'Ошибка при отправке'}</p>`;
                } else {
                    if (msgBox) msgBox.innerHTML = `<p class="api-success">${result.message || 'Успешно отправлено!'}</p>`;
                    formClaim.reset();
                }
            } catch (err) { 
                console.error(err);
                if (msgBox) msgBox.innerHTML = '<p class="api-error">Ошибка соединения с сервером</p>';
            }
        });
    }

    // --- 3.4. ТАБЛИЦА "МОИ ЗАЯВЛЕНИЯ" ---
    const claimsContainer = document.getElementById('claims-table-container');
    if (claimsContainer) {
        if (!token) {
            const claimsAuthWarning = document.getElementById('claims-auth-warning');
            if (claimsAuthWarning) claimsAuthWarning.style.display = 'block';
        } else {
            async function fetchMyClaims() {
                try {
                    const response = await fetch(`${API_URL}/claims`, { 
                        headers: { 'Authorization': `Bearer ${token}` } 
                    });
                    const result = await response.json();
                    const currentDict = i18n[currentLang].texts;

                    if (!result.claims || result.claims.length === 0) {
                        claimsContainer.innerHTML = `<p id="empty-claims" style="text-align:center;">${currentDict['empty-claims']}</p>`;
                        return;
                    }

                    let tableHTML = `
                        <table style="width: 100%; border-collapse: collapse; margin-top: 15px; background: #fff;">
                            <thead>
                                <tr style="background: #007bff; color: white; text-align: left;">
                                    <th style="padding: 10px; border: 1px solid #ddd;">№</th>
                                    <th style="padding: 10px; border: 1px solid #ddd;">ГРНЗ</th>
                                    <th style="padding: 10px; border: 1px solid #ddd;">Мекен Жай / Адрес</th>
                                    <th style="padding: 10px; border: 1px solid #ddd;">Бұзушылық / Нарушение</th>
                                    <th style="padding: 10px; border: 1px solid #ddd;">Статус</th>
                                    <th style="padding: 10px; border: 1px solid #ddd;">Күні / Дата</th>
                                </tr>
                            </thead>
                            <tbody>
                    `;

                    result.claims.forEach(claim => {
                        let statusColor = '#555';
                        if(claim.status === 'Жаңа') statusColor = 'blue';
                        if(claim.status === 'Өңделуде') statusColor = 'orange';
                        if(claim.status === 'Аяқталды') statusColor = 'green';
                        if(claim.status === 'Қабылданбады') statusColor = 'red';

                        tableHTML += `
                            <tr style="border-bottom: 1px solid #eee;">
                                <td style="padding: 10px; border: 1px solid #ddd;">${claim.id}</td>
                                <td style="padding: 10px; border: 1px solid #ddd; font-weight:bold;">${claim.grnz}</td>
                                <td style="padding: 10px; border: 1px solid #ddd;">${claim.address}</td>
                                <td style="padding: 10px; border: 1px solid #ddd;">${claim.violation_type}</td>
                                <td style="padding: 10px; border: 1px solid #ddd; font-weight:bold; color: ${statusColor};">${claim.status}</td>
                                <td style="padding: 10px; border: 1px solid #ddd;">${claim.created_at}</td>
                            </tr>
                        `;
                    });

                    tableHTML += `</tbody></table>`;
                    claimsContainer.innerHTML = tableHTML;

                } catch (err) { 
                    console.error(err);
                    claimsContainer.innerHTML = '<p style="color:red; text-align:center;">Ошибка связи с сервером.</p>';
                }
            }
            fetchMyClaims();
        }
    }
});