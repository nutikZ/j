from fastapi import FastAPI, HTTPException, Request, Depends, File, Form, UploadFile
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, field_validator
from typing import List, Optional
import re
import pymysql
import bcrypt
import jwt
from datetime import datetime, timedelta
import os
import shutil

app = FastAPI(title="Sergek Azamat API")

# --- Раздача статических файлов (ФОТО) ---
# Создаем папку, если ее нет, и разрешаем к ней доступ по ссылке /uploads/...
os.makedirs("uploads", exist_ok=True)
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://sergek.local",
        "https://sergek.local",   # <--- Вот это разрешит запросы с твоего сайта!
        "http://localhost",
        "http://127.0.0.1"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Настройки Базы Данных ---
DB_CONFIG = {
    'host': '127.0.1.16',
    'port': 3306,
    'user': 'root',
    'password': '',
    'database': 'sergek_azamat_db',
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

SECRET_KEY = "sergek_super_secret_key_2026"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 6000

# --- Глобальный перехватчик ошибок валидации ---
@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    errors = {}
    for err in exc.errors():
        field_name = err["loc"][-1]
        errors[field_name] = "Қате формат / Неверный формат"
    return JSONResponse(status_code=400, content={"errors": errors})

# --- Модели валидации ---
class RegisterRequest(BaseModel):
    iin: str = Field(..., pattern=r"^\d{12}$")
    fio: str = Field(..., pattern=r"^[А-Яа-яЁёҚҢҒҮҰӨӘІқңғүұөәі\s]+$")
    # ИСПРАВЛЕНО: Теперь регулярное выражение четко ожидает скобки вокруг кода оператора
    phone: str = Field(..., pattern=r"^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$")
    email: str = Field(..., pattern=r"^[\w\.-]+@[\w\.-]+\.\w+$")
    password: str = Field(..., min_length=8)

    @field_validator('password')
    def validate_password(cls, v):
        if not re.search(r"[A-Z]", v):
            raise ValueError('Пароль должен содержать заглавную букву')
        if not re.search(r"\d", v):
            raise ValueError('Пароль должен содержать цифру')
        return v

class LoginRequest(BaseModel):
    iin: str
    password: str

class AdminLoginRequest(BaseModel):
    login: str
    password: str

class StatusUpdateRequest(BaseModel):
    status: str

security = HTTPBearer()

# --- Проверка JWT ---
def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload["user_id"]
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Токеннің уақыты өтті / Срок действия токена истек")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Жарамсыз токен / Невалидный токен")


# ==========================================
# ЭНДПОИНТЫ ДЛЯ ГРАЖДАН (ВЕБ-САЙТ)
# ==========================================

@app.post("/api/register")
async def register_user(user: RegisterRequest):
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(user.password.encode('utf-8'), salt).decode('utf-8')
    connection = None
    try:
        connection = pymysql.connect(**DB_CONFIG)
        with connection.cursor() as cursor:
            cursor.execute("SELECT id FROM users WHERE iin = %s", (user.iin,))
            if cursor.fetchone():
                return JSONResponse(status_code=400, content={"errors": {"iin": "Бұл ЖСН тіркелген / Этот ИИН уже зарегистрирован"}})

            insert_sql = "INSERT INTO users (iin, fio, phone, email, password_hash) VALUES (%s, %s, %s, %s, %s)"
            cursor.execute(insert_sql, (user.iin, user.fio, user.phone, user.email, hashed_password))
            connection.commit()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка: {str(e)}")
    finally:
        if connection and connection.open: connection.close()
    return {"message": "Тіркелу сәтті өтті! / Регистрация прошла успешно!"}

@app.post("/api/login")
async def login_user(user: LoginRequest):
    connection = None
    try:
        connection = pymysql.connect(**DB_CONFIG)
        with connection.cursor() as cursor:
            cursor.execute("SELECT id, password_hash FROM users WHERE iin = %s", (user.iin,))
            db_user = cursor.fetchone()

            if not db_user or not bcrypt.checkpw(user.password.encode('utf-8'), db_user['password_hash'].encode('utf-8')):
                return JSONResponse(status_code=401, content={"detail": "ЖСН немесе құпия сөз қате / Неверный ИИН или пароль"})

            expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
            to_encode = {"sub": user.iin, "user_id": db_user['id'], "exp": expire.timestamp()}
            encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
            return {"access_token": encoded_jwt, "token_type": "bearer"}
    finally:
        if connection and connection.open: connection.close()

@app.post("/api/claims")
async def create_claim(
        violation_type_id: int = Form(...),
        grnz: str = Form(..., pattern=r"^\d{3}[A-Za-z]{2,3}\d{2}$"),
        region_code: int = Form(..., ge=1, le=20),
        address: str = Form(...),
        priority: str = Form("Средний"),
        description: str = Form(...),
        # ЯВНО УКАЗЫВАЕМ 3 ОТДЕЛЬНЫХ ФАЙЛА (ЭТО ИСПРАВИТ SWAGGER)
        photo1: Optional[UploadFile] = File(None),
        photo2: Optional[UploadFile] = File(None),
        photo3: Optional[UploadFile] = File(None),
        user_id: int = Depends(verify_token)
):
    connection = None
    try:
        connection = pymysql.connect(**DB_CONFIG)
        with connection.cursor() as cursor:
            sql_claim = """
                        INSERT INTO claims (user_id, violation_type_id, grnz, region_code, address, description, priority, status)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, 'Жаңа')
                        """
            cursor.execute(sql_claim, (user_id, violation_type_id, grnz.upper(), region_code, address, description, priority))
            claim_id = cursor.lastrowid

            # Собираем загруженные фото в один список, игнорируя пустые
            photos = [p for p in (photo1, photo2, photo3) if p is not None]

            if photos:
                for photo in photos:
                    timestamp = datetime.now().strftime("%Y%m%d%H%M%S%f")
                    safe_filename = f"{timestamp}_{photo.filename}"
                    file_path = f"uploads/{safe_filename}"

                    with open(file_path, "wb") as buffer:
                        shutil.copyfileobj(photo.file, buffer)

                    cursor.execute("INSERT INTO claim_photos (claim_id, photo_url) VALUES (%s, %s)", (claim_id, file_path))

            connection.commit()
    except Exception as e:
        if connection: connection.rollback()
        raise HTTPException(status_code=500, detail=f"Ошибка БД: {str(e)}")
    finally:
        if connection and connection.open: connection.close()

    return {"message": "Өтініш сәтті қабылданды! / Заявление успешно принято!"}

@app.get("/api/claims")
async def get_my_claims(user_id: int = Depends(verify_token)):
    connection = None
    try:
        connection = pymysql.connect(**DB_CONFIG)
        with connection.cursor() as cursor:
            sql = """
                  SELECT c.id, c.grnz, c.address, vt.name as violation_type, c.status, c.created_at
                  FROM claims c
                  JOIN violation_types vt ON c.violation_type_id = vt.id
                  WHERE c.user_id = %s
                  ORDER BY c.created_at DESC
                  """
            cursor.execute(sql, (user_id,))
            claims = cursor.fetchall()

            for claim in claims:
                if isinstance(claim['created_at'], datetime):
                    claim['created_at'] = claim['created_at'].strftime("%Y-%m-%d %H:%M:%S")

            return {"claims": claims}
    finally:
        if connection and connection.open: connection.close()

# ==========================================
# ЭНДПОИНТЫ ДЛЯ ИНСПЕКТОРА (C++ DESKTOP APP)
# ==========================================

@app.post("/api/admin/login")
async def admin_login(data: AdminLoginRequest):
    # Жестко заданный логин/пароль по требованиям ТЗ
    if data.login == "mvd_admin" and data.password == "KzPolice2026!":
        return {"access_token": "ADMIN_TOKEN_123", "token_type": "bearer"}
    raise HTTPException(status_code=401, detail="Неверный логин или пароль")

@app.get("/api/admin/claims")
async def get_all_claims():
    connection = pymysql.connect(**DB_CONFIG)
    try:
        with connection.cursor() as cursor:
            sql = """
                  SELECT c.id, c.created_at, c.address, vt.name as violation_type, 
                         c.status, c.priority, c.description, u.iin, c.grnz, c.region_code
                  FROM claims c 
                  LEFT JOIN users u ON c.user_id = u.id
                  LEFT JOIN violation_types vt ON c.violation_type_id = vt.id
                  """
            cursor.execute(sql)
            claims = cursor.fetchall()
            for claim in claims:
                if isinstance(claim['created_at'], datetime):
                    claim['created_at'] = claim['created_at'].strftime("%Y-%m-%d %H:%M")
                claim['iin'] = claim.get('iin') or "Неизвестно"
                claim['violation_type'] = claim.get('violation_type') or str(claim.get('violation_type_id', '1'))
            return {"claims": claims}
    finally:
        connection.close()

@app.patch("/api/admin/claims/{claim_id}/status")
async def update_claim_status(claim_id: int, request: StatusUpdateRequest):
    connection = pymysql.connect(**DB_CONFIG)
    try:
        with connection.cursor() as cursor:
            cursor.execute("UPDATE claims SET status = %s WHERE id = %s", (request.status, claim_id))
            connection.commit()
        return {"message": "Статус успешно обновлен"}
    finally:
        connection.close()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)